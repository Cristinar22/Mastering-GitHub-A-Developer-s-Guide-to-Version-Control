
# git clone command
git clone https://github.com/username/repository-name.git
    