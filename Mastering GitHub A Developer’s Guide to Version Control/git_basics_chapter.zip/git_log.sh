
# git log command
git log
    