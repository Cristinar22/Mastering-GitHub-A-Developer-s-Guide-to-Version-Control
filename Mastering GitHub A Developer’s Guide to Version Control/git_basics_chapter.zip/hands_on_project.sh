
# Steps to track changes to a simple text file
# 1. Initialize Git in the directory
mkdir my-first-git-project
cd my-first-git-project
git init

# 2. Create a text file
echo "This is my first file with Git. It tracks changes to the content." > notes.txt

# 3. Stage and commit the file
git add notes.txt
git commit -m "Initial commit with notes.txt"

# 4. Add another line to the file
echo "Adding a second line to track changes." >> notes.txt

# 5. Stage and commit the new change
git add notes.txt
git commit -m "Added a second line to the file"

# 6. View the commit log
git log
    