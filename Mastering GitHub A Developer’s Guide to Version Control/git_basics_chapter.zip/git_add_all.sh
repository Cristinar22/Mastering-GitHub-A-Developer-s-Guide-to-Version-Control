
# git add all modified files
git add .
    