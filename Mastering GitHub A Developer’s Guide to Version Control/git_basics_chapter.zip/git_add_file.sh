
# git add specific file
git add file.txt
    