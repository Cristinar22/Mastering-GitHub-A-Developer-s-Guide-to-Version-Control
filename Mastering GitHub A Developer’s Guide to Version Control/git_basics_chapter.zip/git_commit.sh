
# git commit command with a message
git commit -m "Added a new feature"
    