
# git init command
git init
    