
# git status command
git status
    