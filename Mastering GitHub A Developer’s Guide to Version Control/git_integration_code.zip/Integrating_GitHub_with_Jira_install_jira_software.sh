
        # Install Jira Software Cloud App for GitHub
        Visit the Jira Software Cloud app marketplace and search for GitHub for Jira.
        Install the app and authenticate with both your Jira and GitHub accounts.
        