
        # Steps to install GitHub app on Slack
        Go to the Slack App Directory and search for the GitHub app.
        Install the GitHub app in your Slack workspace.
        