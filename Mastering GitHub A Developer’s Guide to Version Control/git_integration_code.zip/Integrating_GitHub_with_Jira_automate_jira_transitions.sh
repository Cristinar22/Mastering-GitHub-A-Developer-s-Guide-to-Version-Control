
        # Automate Jira transitions based on GitHub activity
        When a pull request is merged, Jira can move the issue to the "Done" state.
        