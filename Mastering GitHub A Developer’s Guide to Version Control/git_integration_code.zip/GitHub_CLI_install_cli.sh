
        # Install GitHub CLI
        Follow the installation instructions for your operating system.
        