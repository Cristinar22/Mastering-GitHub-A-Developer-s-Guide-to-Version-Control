
        # Link commits to Jira issues
        Include the Jira issue key in the commit message:
        git commit -m "Fix login bug, PROJ-123"
        