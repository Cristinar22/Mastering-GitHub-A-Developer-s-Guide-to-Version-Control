
        # Create a GitHub pull request via CLI
        gh pr create --base main --head feature-branch --title "Fix login bug" --body "This PR fixes the login bug."
        