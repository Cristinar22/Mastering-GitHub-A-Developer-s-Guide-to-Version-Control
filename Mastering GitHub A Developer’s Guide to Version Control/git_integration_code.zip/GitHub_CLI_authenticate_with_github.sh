
        # Authenticate with GitHub CLI
        gh auth login
        