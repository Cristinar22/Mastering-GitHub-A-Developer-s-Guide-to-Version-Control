
        # GitHub Actions for deploying to Azure
        name: Deploy to Azure
        on:
          push:
            branches:
              - main
        jobs:
          deploy:
            runs-on: ubuntu-latest
            steps:
              - name: Checkout code
                uses: actions/checkout@v2
              - name: Deploy to Azure WebApp
                uses: azure/webapps-deploy@v2
                with:
                  app-name: your-app-name
                  publish-profile: ${{ secrets.AZURE_PUBLISH_PROFILE }}
                  package: '.'
        