
        # Create a GitHub issue via CLI
        gh issue create --title "Fix login bug" --body "Login page not working as expected."
        