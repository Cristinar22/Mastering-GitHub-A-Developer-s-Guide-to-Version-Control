bash
git reset --hard HEAD~1
    