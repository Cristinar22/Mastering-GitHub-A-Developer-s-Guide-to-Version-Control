bash
git rebase -i HEAD~4
    