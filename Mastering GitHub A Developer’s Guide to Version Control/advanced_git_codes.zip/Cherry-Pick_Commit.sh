bash
git log
git cherry-pick 34acb2a
    