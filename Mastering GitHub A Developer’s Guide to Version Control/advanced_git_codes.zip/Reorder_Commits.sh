text
pick a2b9c7b Fix bug in login form
pick f4d1a4a Add login functionality
pick 34acb2a Update styles for login page
pick 6e8a3d0 Add tests for login functionality
pick 4f6e3c5 Refactor login function
    