bash
git reset --soft HEAD~1
    