bash
git rebase -i HEAD~5
    