bash
git reset HEAD~1
    