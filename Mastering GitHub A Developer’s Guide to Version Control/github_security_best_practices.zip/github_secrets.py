# Store and use GitHub secrets
# 1. Go to repository Settings > Secrets > New repository secret
# 2. Store a secret, e.g., DB_PASSWORD = 'your_secret_password'
# 3. Reference secrets in GitHub Actions
env:
    DB_PASSWORD: ${{ secrets.DB_PASSWORD }}