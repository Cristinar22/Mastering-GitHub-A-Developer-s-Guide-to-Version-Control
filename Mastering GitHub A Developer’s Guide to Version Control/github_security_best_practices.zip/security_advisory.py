# Steps to create a GitHub security advisory
# Navigate to your repository > Security tab > Advisories > New advisory
# Add details about the vulnerability, affected versions, and assign fixes.