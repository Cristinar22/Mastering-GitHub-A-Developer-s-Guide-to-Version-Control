# Creating a Milestone
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/repos/OWNER/REPO/milestones -d '{"title":"Version 1.0 Release","due_on":"2025-05-15T00:00:00Z"}'

# Labeling issues
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/repos/OWNER/REPO/issues/ISSUE_ID/labels -d '{"labels":["high priority"]}'

# Example of creating an Issue Template for Bug Reports
echo -e "### Steps to Reproduce
- Step 1
- Step 2
### Expected Behavior
- Description
### Actual Behavior
- Description" > .github/ISSUE_TEMPLATE/bug_report.md
