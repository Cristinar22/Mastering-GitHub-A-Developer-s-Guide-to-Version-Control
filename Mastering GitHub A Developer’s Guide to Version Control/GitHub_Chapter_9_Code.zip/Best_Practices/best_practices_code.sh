# GitHub Issue Best Practices

# Be Specific in Issue Descriptions:
# Instead of vague descriptions like 'Fix bug', write detailed explanations like 'Fix login issue where incorrect password causes app crash'

# Use Labels to Prioritize:
# Use 'high priority' labels for critical issues and 'low priority' labels for less urgent tasks.
