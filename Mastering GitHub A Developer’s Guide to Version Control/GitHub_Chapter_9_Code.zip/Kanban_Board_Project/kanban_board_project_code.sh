# Hands-On Project: Set Up a Kanban Board for a Small Project

# Steps to create a GitHub repository and project board
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/user/repos -d '{"name":"kanban-board-demo"}'

# Add Issues to Kanban Board
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/repos/OWNER/REPO/projects/PROJECT_ID/cards -d '{"content_id":ISSUE_ID,"content_type":"Issue"}'
