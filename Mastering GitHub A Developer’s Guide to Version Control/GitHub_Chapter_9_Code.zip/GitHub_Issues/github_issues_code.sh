# Create GitHub Issues for tasks, bugs, feature requests
# Example commands to create issues:

# Creating a bug issue
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/repos/OWNER/REPO/issues -d '{"title":"Fix login form error","body":"Login form does not display error message when wrong credentials are entered","labels":["bug"]}'

# Creating a feature request issue
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/repos/OWNER/REPO/issues -d '{"title":"Implement password reset functionality","body":"Allow users to reset their passwords through an email link.","labels":["feature"]}'
