# Setup GitHub Project Boards
# Create a Kanban Board with the following columns: 'To Do', 'In Progress', 'Done'
# Command to create a new project with a Kanban board layout
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/repos/OWNER/REPO/projects -d '{"name":"Kanban Board","body":"Project board for task tracking","column_names":["To Do","In Progress","Done"]}'

# Assign an issue to the board
curl -X POST -u "USERNAME:TOKEN" -H "Accept: application/vnd.github.v3+json" https://api.github.com/projects/PROJECT_ID/cards -d '{"content_id":ISSUE_ID,"content_type":"Issue"}'
